package kr.project.memo01;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kr.project.memo01.dao.MemoDAO;
import kr.project.memo01.service.MemoService;
import kr.project.memo01.service.TestService;
import kr.project.memo01.vo.MemoVO;
import kr.project.memo01.vo.PageList;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	private TestService testService; 
	
	@Autowired
	private MemoService memoService; 
	
	public void setTestService(TestService testService) {
		this.testService = testService;
	}
	public void setMemoService(MemoService memoService) {
		this.memoService = memoService;
	}

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value= "/date")
	public String getDate(Model model){
		String date = testService.getDate();
		model.addAttribute("date", date );
		return "date";
	}
	
	@RequestMapping(value= "/cnt")
	public String getCount(Model model){
		int cnt =memoService.getCount();
		model.addAttribute("cnt",cnt);
		return "cnt";
	}
	
	@RequestMapping(value= "/delete")
	public String delete(@RequestParam int idx){
		memoService.delete(idx);
		return "redirect:/memo";
	}
	
	@RequestMapping(value= "/update")
	public String update(@RequestParam int idx, @RequestParam String subject){
		memoService.update(idx, subject);
		return "redirect:/memo";
	}
	
	// ����ڰ� ���� �Է��ϰ� �����ϸ� 
	// ������ �Ѿ���µ� �������� �޾��ִ³��� @ModelAttribute �̴�
	@RequestMapping(value= "/insertOK")
	public String insertOK(@ModelAttribute MemoVO vo){
		memoService.insert(vo);
		return "redirect:/memo";
	}
	
/*	@RequestMapping(value= "/memo")
	public String memo(){
		return "memo";
	}*/
	
	/*	@RequestMapping(value= "/memo")
	public String memo(Model model){
		List<MemoVO> list = memoService.selectList();
		model.addAttribute("list",list);
		return "memo";
	}*/
	
	@RequestMapping(value= "/memo")
	public String selectList(HttpServletRequest request ,Model model){
		int currentPage = 1;
		int pageSize = 10;
		int blockSize = 10;
		
		try{
		currentPage = Integer.parseInt(request.getParameter("p"));
		}catch (Exception e) {;}
		try{
		pageSize = Integer.parseInt(request.getParameter("s"));
		}catch (Exception e) {;}
		try{
		blockSize = Integer.parseInt(request.getParameter("b"));
		}catch (Exception e) {;}
		
		PageList<MemoVO> pageList = memoService.selectList(currentPage, pageSize, blockSize);
		model.addAttribute("pageList",pageList);
		
		return "memo";
	}
	

	
	
}
