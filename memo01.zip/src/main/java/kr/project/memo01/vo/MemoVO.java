package kr.project.memo01.vo;

public class MemoVO {
	private int idx;
	private String subject;
	
	public MemoVO() {
	}

	public MemoVO(int idx, String subject) {
		super();
		this.idx = idx;
		this.subject = subject;
	}

	public int getIdx() {
		return idx;
	}

	public void setIdx(int idx) {
		this.idx = idx;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "MemoVO [idx=" + idx + ", subject=" + subject + "]";
	}
	
}	
