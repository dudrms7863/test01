package kr.project.memo01.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.project.memo01.dao.MemoDAO;
import kr.project.memo01.vo.MemoVO;
import kr.project.memo01.vo.PageList;

@Service
public class MemoService {
	
	@Autowired
	private MemoDAO memoDAO;

	public void setMemoDAO(MemoDAO memoDAO) {
		this.memoDAO = memoDAO;
	}

	public void insert(MemoVO vo){
		memoDAO.insert(vo);
	}
	
	public int getCount(){
		return memoDAO.getCount();
	}
	

/*	public List<MemoVO> selectList(){
		return memoDAO.selectList();
	}		*/
	
	public PageList<MemoVO> selectList(int currentPage, int pageSize , int blockSize){
		int totalCount = memoDAO.getCount();
		PageList<MemoVO> pageList = new PageList<MemoVO>(totalCount, currentPage, pageSize, blockSize);
		List<MemoVO> list = memoDAO.selectList(pageList.getStartNo(),pageList.getPageSize());
		pageList.setList(list);
		return pageList;
	}
	
	public void delete(int idx){
		memoDAO.delete(idx);
	}
	
	public void update(int idx,String subject){
		memoDAO.update(idx,subject);
	}
	
}
