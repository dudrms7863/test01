package kr.project.memo01.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.project.memo01.vo.MemoVO;
import kr.project.memo01.vo.PageList;

@Repository
public class MemoDAO {
	
	@Autowired
	private SqlSession sqlSession ;

	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public void insert(MemoVO vo){
		sqlSession.insert("memo.insert",vo );
	}
	
	public int getCount(){
		return sqlSession.selectOne("memo.getCount");
	}
	
/*	public List<MemoVO> selectList(){
		List<MemoVO> list = sqlSession.selectList("memo.selectList");
		return list;
	}
	*/
	
	public List<MemoVO> selectList(int startNo , int pageSize){
			HashMap<String,Integer > map = new HashMap<String,Integer >();
			map.put("startNo", startNo);
			map.put("pageSize", pageSize);
			List<MemoVO> list = sqlSession.selectList("memo.selectList",map);
		return list;
	}
	
	public void delete(int idx){
		HashMap<String,Integer > map = new HashMap<String,Integer >();
		map.put("idx", idx);
		sqlSession.delete("memo.delete",map);
	}
	
	public void update(int idx,String subject){
		HashMap<String,String > map = new HashMap<String,String >();
		map.put("idx", idx+"");
		map.put("subject", subject);
		sqlSession.update("memo.update",map);
	}
	
	
	
}
